define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createPostIcApiIntegrationV1FlowsRestLEAVEMANAGEMENTORCHESTRAT1EndpointRestChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.CreateVar = true;

      try {
        // Validates postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validatePostIcApiIntegrationV1FlowsRestLEAVEMANAGEMENTORCHESTRAT1EndpointRest' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'Leave_Service/postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest',
          body: $variables.RequestVar,
        }, { id: 'createPostIcApiIntegrationV1FlowsRestLEAVEMANAGEMENTORCHESTRAT1EndpointRest' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = `Could not create new postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: 'postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest saved',
          message: 'postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.CreateVar = false;
      }
    }
  }

  return createPostIcApiIntegrationV1FlowsRestLEAVEMANAGEMENTORCHESTRAT1EndpointRestChain;
});
