define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitLeaves extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.RequestVar.action = 'SUBMIT';

      $variables.RequestVar.empId = $application.variables.GBLEmpID;
      $variables.RequestVar.status = 'PENDING';

      const response = await Actions.callRest(context, {
        endpoint: 'Leave_Service/postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest',
        body: $variables.RequestVar,
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Submitted',
        message: 'Your leave is submitted',
        displayMode: 'transient',
        type: 'confirmation',
      }, { id: 'Created' });

      await Actions.navigateBack(context, {
      });
    }
  }

  return SubmitLeaves;
});
