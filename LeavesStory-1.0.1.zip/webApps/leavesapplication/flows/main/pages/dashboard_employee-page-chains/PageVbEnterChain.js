define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if ($application.variables.GBLRolevar === 'MANAGER') {

        // checkRole
          $variables.RequestVar.action = 'GET_PENDING';
        $variables.RequestVar.empId = $application.variables.GBLEmpID;

        const response = await Actions.callRest(context, {
          endpoint: 'Leave_Service/postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest',
          body: $variables.RequestVar,
        }, { id: 'callManager' });

        $variables.LeaveListVar.data = response.body.leaveList;
      } else {

        // checkRole
          $variables.RequestVar.action = 'GET_MY_LEAVES';
        $variables.RequestVar.empId = $application.variables.GBLEmpID;

        const response2 = await Actions.callRest(context, {
          endpoint: 'Leave_Service/postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest',
          body: $variables.RequestVar,
        });

        $variables.LeaveListVar.data = response2.body.leaveList;
      }
    }
  }

  return PageVbEnterChain;
});
