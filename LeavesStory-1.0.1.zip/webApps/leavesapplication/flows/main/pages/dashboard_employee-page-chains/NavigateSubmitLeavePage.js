define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class NavigateSubmitLeavePage extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const toSubmityourleaves = await Actions.navigateToPage(context, {
        page: 'submityourleaves',
      }, { id: 'navigatetocreateleaves' });
    }
  }

  return NavigateSubmitLeavePage;
});
