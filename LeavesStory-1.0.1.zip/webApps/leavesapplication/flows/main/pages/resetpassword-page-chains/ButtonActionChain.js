define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.ResetVar.ACTION = 'UPDATE_PASSWORD';

      const response = await Actions.callRest(context, {
        endpoint: 'Employee_t/postIcApiIntegrationV1FlowsRestLOGIN_SIGNUP_LM_INT1_0Login',
        body: $variables.ResetVar,
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Success',
        message: 'Reset Password Successfully',
        displayMode: 'transient',
        type: 'confirmation',
      });

      await Actions.navigateBack(context, {
      });
    }
  }

  return ButtonActionChain;
});
