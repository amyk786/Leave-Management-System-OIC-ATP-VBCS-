define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.EmployeeVar.ACTION = 'CREATE_NEW_EMPLOYEE';
      $variables.EmployeeVar.LOGIN_PASSWORD = 'Welcome@123';
      $variables.EmployeeVar.MANAGER_ID = '1001';
      $variables.EmployeeVar.ROLE = 'EMPLOYEE';

      const response = await Actions.callRest(context, {
        endpoint: 'Employee_t/postIcApiIntegrationV1FlowsRestLOGIN_SIGNUP_LM_INT1_0Login',
        body: $variables.EmployeeVar,
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Success!!',
        message: 'User Created with ManagerID: '+response.body.MANAGER_ID + ' and your default password is :'+response.body.LOGIN_PASSWORD,
        type: 'confirmation',
      });

      await Actions.navigateBack(context, {
      });
    }
  }

  return ButtonActionChain;
});
