define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitYourLeaves extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.RequestVar.action = 'UPDATE_STATUS';

      const response = await Actions.callRest(context, {
        endpoint: 'Leave_Service/postIcApiIntegrationV1FlowsRestLEAVE_MANAGEMENT_ORCHESTRAT1_0Endpoint_rest',
        body: $variables.RequestVar,
      });

      await Actions.fireNotificationEvent(context, {
        message: response.body.message,
        summary: response.body.status,
        displayMode: 'transient',
        type: 'info',
      });

      await Actions.navigateBack(context, {
      });
    }
  }

  return SubmitYourLeaves;
});
