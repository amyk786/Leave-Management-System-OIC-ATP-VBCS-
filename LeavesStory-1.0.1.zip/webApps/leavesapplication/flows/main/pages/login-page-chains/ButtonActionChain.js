define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.EMPLOYEE.ACTION = 'LOGIN';

      const response = await Actions.callRest(context, {
        endpoint: 'Employee_t/postIcApiIntegrationV1FlowsRestLOGIN_SIGNUP_LM_INT1_0Login',
        body: $variables.EMPLOYEE,
      });

      if (response.body.STATUS === 'SUCCESS') {
        $application.variables.GBLName = response.body.NAME;
        $application.variables.GBLEmpID = response.body.EMP_ID;
        $application.variables.GBLRolevar = response.body.ROLE;

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'You are successfully logged in',
          displayMode: 'transient',
          type: 'confirmation',
        });

        if (response.body.ROLE === 'MANAGER') {
          const toDashboardManager = await Actions.navigateToPage(context, {
            page: 'dashboard_manager',
          });
        } else {
          const toDashboardEmployee = await Actions.navigateToPage(context, {
            page: 'dashboard_employee',
          });
        }
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error',
          message: 'Invalid Credentials',
        });
      }
    }
  }

  return ButtonActionChain;
});
